import React from 'react';
// import './Home.css';

export default () => (
  <div className="Home ">
    <h1>Sobre Wesley</h1>
  </div>
);