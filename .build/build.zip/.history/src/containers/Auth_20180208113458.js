import { Container } from 'unstated'
import firebase from 'firebase';

const tokenName = 'wm-token'

export default class extends Container {
  state = {
    uid: null
  };

  login = (email, password) => {
    firebase.auth().signInWithEmailAndPassword(email, password)
      .then((data) => {
        console.log('Success', data.token)
        localStorage.setItem(tokenName, data.token);
        this.setState({ uid: data.uid });
      })
      .catch((error) => {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      if (errorCode === 'auth/wrong-password') {
        alert('Wrong password.');
      } else {
        alert(errorMessage);
      }
      console.log(error);
    });
  }

  logout = () => {
    this.setState({ uid: null });
    localStorage.removeItem(tokenName);
  }
}