import { Container } from 'unstated'
import firebase from 'firebase';

export default class extends Container {
  state = {
    loading: true,
    data: []
  };

  load = (id) => {
    let refKey = 'portfolio'
    if (id) {
      refKey = `portfolio/${id}`
    }
    const projects = []
    const ref = firebase.database().ref(refKey)
    ref.on('value', (snapshot) => {
      snapshot.forEach(data => {
        projects.push(data.val())
      })
      this.setState({
        loading: false,
        data: projects
      })
    })
  }

  
}