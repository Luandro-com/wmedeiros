import { Container } from 'unstated'

export default class extends Container {
  state = {
    uid: null
  };

  login(uid) {
    this.setState({ uid: uid });
  }

  logout() {
    this.setState({ uid: null });
  }
}