import { Container } from 'unstated'
import firebase from 'firebase';

export default class extends Container {
  state = {
    loading: true,
    data: []
  };

  add = (data, callback) => {
    const newKey = firebase.database().ref().child('portfolio').push().key;
    firebase.database().ref(`portfolio/${newKey}`).set(data)
      .then(() => callback())
      .catch((err) => console.log('err on sending data', err))
  }

  remove = (id) => {
    console.log('ID', id)
    const refKey = `portfolio/${id}`
    firebase.database().ref(refKey).remove()
      .then(() => console.log('Deleted'))
      .catch(err => console.log('Error on delete', err))
  }

  load = (id) => {
    let refKey = 'portfolio'
    if (id) {
      refKey = `portfolio/${id}`
    }
    const projects = []
    const ref = firebase.database().ref(refKey)
    ref.on('value', (snapshot) => {
      snapshot.forEach(data => {
        console.log('data', data)
        // data.concat({ id: data.key})
        projects.push(data.val())
      })
      console.log(projects)
      this.setState({
        loading: false,
        data: projects
      })
    })
  }

  
}