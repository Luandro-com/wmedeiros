import { Container } from 'unstated'
import firebase from 'firebase';

export default class extends Container {
  state = {
    data: null
  };

  
}