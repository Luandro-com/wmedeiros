import React from 'react'
import { Provider, Container } from 'unstated'
import Router from './router'

class AuthContainer extends Container {
  state = {
    uid: null
  };

  login(uid) {
    this.setState({ uid: uid });
  }

  logout() {
    this.setState({ uid: null });
  }
}

export default () => <Provider><Router /></Provider>