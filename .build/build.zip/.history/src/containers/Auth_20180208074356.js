import { Container } from 'unstated'

export default class extends Container {
  state = {
    uid: null
  };

  login(email, password) {
    firebase.auth().signInWithEmailAndPassword(email, password)
      .then((data) => {
        console.log('Success', data.uid)
        this.setState({ uid: data.uid });
      })
      .catch((error) => {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      if (errorCode === 'auth/wrong-password') {
        alert('Wrong password.');
      } else {
        alert(errorMessage);
      }
      console.log(error);
    });
  }

  logout() {
    this.setState({ uid: null });
  }
}