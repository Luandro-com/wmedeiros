import React from 'react'
import { Provider, Container } from 'unstated'
import Router from './router'

class CounterContainer extends Container {
  state = {
    count: 0
  };

  increment() {
    this.setState({ count: this.state.count + 1 });
  }

  decrement() {
    this.setState({ count: this.state.count - 1 });
  }
}

export default () => <Provider><Router /></Provider>