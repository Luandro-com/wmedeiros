import React from 'react';
import firebase from 'firebase';
import { Form, Field } from 'simple-react-form';
import './Login.css';

export default () => (
  <div className="Login">
    <form>
    </form>
  </div>
);