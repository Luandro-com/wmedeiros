import React from 'react';
// import './Home.css';

export default () => (
  <div className="Home">
    <h1>Home</h1>
  </div>
);