import React from 'react';
// import './Home.css';

export default () => (
  <div className="Home detail-page">
    <h1>Contato</h1>
  </div>
);